﻿<?php
$begin = 0;
$limit=100;//默认每次返回100条数据
$animalChineseName= "猪";
$db="server";
$passSQL="";
if(isset($_REQUEST['passsql']))
{
	$passSQL=$_REQUEST['passsql'];
}
//>>>>>数据返回模式参数
$isDisPlayCurrent = false;
//<<<<<数据返回模式参数
if(isset($_REQUEST['mode']))
{
	$isDisPlayCurrent=true;
}
if(isset($_REQUEST['limit']))
{
	$limit=$_REQUEST['limit'];	
}
if(isset($_POST['db'])){
	$db=$_POST['db'];	
}
if(isset($_POST['animal']))
{
	$animalChineseName=$_POST['animal'];
}
if(isset($_POST['begin']))
{
	$begin = $_POST['begin'];
}
$result="NULL";
header("Content-Type:text/html;charset=utf-8");
if(!$isDisPlayCurrent)
{
	require_once("../print_search_result_before_table.php");	
}

require_once("sqlQueryInAndOut.inc.php");
printSQLresultAsTable();
mysqli_free_result($result);
if(!$isDisPlayCurrent)
{
require_once("../print_search_result_after_table.php");	
}
?>