<html lang="en">
<head>
  <title>Domestic Fertility Database</title>
  <meta charset="utf-8">
  <meta name="author" content="szj">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name= "keyword" content="demostic fertility">
   <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./css/default.index.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="/bysj1/js/baidustatistic.js"></script>
</head>
<body>

<div class=" container" id="header" >
<div class="jumbotron">
    <h1><strong>Demoestic Fertility Database<strong></h1><!--����˵������><-->
</div>
<!--���뵼����-->
<ul class="nav nav-tabs nav-justified">
	<li><a href="index.php">Home</a></li>
	<li><a href="search.php">Search</a></li>
	<li class="active"><a href="#">Download</a></li>
	<li><a href="/cubes/cubesviewer-2.0.2/html/studio1.html">Analyse</a></li>
	<li><a href="contact.php">Contact</a></li>
</ul>
<!--�������������-->
</div>






<div class="container" id="body" >

<div class = "container" id="footer">

</div>
  



</body>
</html>