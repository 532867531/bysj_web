<!DOCTYPE html>
<html lang="en" manifest="statci_index.appcache">
<head>
  <title>Domestic Fertility Database</title>
  <meta charset="utf-8">
  <meta name="author" content="szj">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name= "keyword" content="demostic fertility">
   <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/default.index.css">
 </head>
<body>

<div class=" container" id="header" >
<div class="jumbotron">
    <h1><strong>Demoestic Fertility Database<strong></h1><!--加入说明文字><-->
</div>
<!--加入导航栏-->
<ul class="nav nav-tabs nav-justified">
	<li class="active"><a href="#">Home</a></li>
	<li><a href="search.php">Search</a></li>
	<li><a href="download.php">Download</a></li>
	<li><a href="analyse.php">Analyse</a></li>
	<li><a href="contact.php">Contact</a></li>
</ul>
<!--导航栏加入结束-->
</div>

<div class="container" id="body">
填入信息
</div>
<div class = "container" id="footer">
填入脚信息
<div>
  



</body>
</html>