﻿<?php
header("Content-Type:text/html;charset=utf-8");
echo <<<HEREDOC
<!DOCTYPE html>
<html>
  <head>
    <meta charset=utf-8 />
    <meta name="viewport" content="user-scalable=yes, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, minimal-ui">

    <title>Cola.js/Cytoscape.js</title>

    <link rel="stylesheet" href="./bootstrap.min.css">
    <link rel="stylesheet" href="./bootstrap-theme.min.css">
    <link rel="stylesheet" href="./bootstrap-slider.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link href="./jquery.qtip.min.css" rel="stylesheet" type="text/css" />
    <link href="style.css" rel="stylesheet" />

    <script src="./fastclick.min.js"></script>
    <script src="./lodash.min.js"></script>
    <script src="./jquery.min.js"></script>
    <script src="./bootstrap.min.js"></script>
    <script src="./bootstrap-slider.min.js"></script>
    <script src="./cola.js"></script>
    <script src="../js/cytoscape.min.js"></script>
    <script src="./jquery.qtip.min.js"></script>
    <script src="./cytoscape-qtip.js"></script>
    <script src="./cytoscape-cola.js"></script>



    <script src="code.js"></script>
  </head>
  <body>
    <div id="cy"></div>

    <span class="fa fa-bars config-toggle" id="config-toggle"></span>

    <div id="config" class="config">

      <div class="preamble">
        <span class="label label-info">Cola.js/Cytoscape.js demo</span>

        <p>This is a demo of a graph of gene-gene interactions that uses Cola.js for layout and Cytoscape.js for its graph model and visualisation.  Use the controls below to alter the Cola.js layout parameters.</p>
        <p>
          Data by <a href="http://genemania.org">GeneMANIA</a><br/>
          Visualisation by <a href="http://js.cytoscape.org">Cytoscape.js</a><br/>
          Layout by <a href="http://marvl.infotech.monash.edu/webcola/">Cola.js</a>
        </p>
      </div>

    </div>
  </body>
</html>
HEREDOC;
?>