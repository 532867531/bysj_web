<?php
function PrintstudioShead(){
echo <<<HRERDOC
    <link rel="icon" type="image/png" href="../cubes/cubesviewer-2.0.2/html/img/favicon/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="../cubes/cubesviewer-2.0.2/html/img/favicon/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="../cubes/cubesviewer-2.0.2/html/img/favicon/favicon-96x96.png" sizes="96x96">
    <link rel="shortcut icon" href="../cubes/cubesviewer-2.0.2/html/img/favicon/favicon.ico">


    <link rel="stylesheet" href="../cubes/cubesviewer-2.0.2/html/lib/angular-ui-grid/ui-grid.css" />
    <link rel="stylesheet" href="../cubes/cubesviewer-2.0.2/html/lib/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="../cubes/cubesviewer-2.0.2/html/lib/nvd3/nv.d3.css" />
    <link rel="stylesheet" href="../cubes/cubesviewer-2.0.2/dist/cubesviewer.css" />
    <link rel="stylesheet" href="../cubes/cubesviewer-2.0.2/html/lib/bootstrap-submenu/css/bootstrap-submenu.css" /> <!-- after cubesviewer.css! -->

    <link rel="stylesheet" href="../cubes/cubesviewer-2.0.2/html/cvapp.css" />

    <script src="../cubes/cubesviewer-2.0.2/html/lib/jquery/jquery.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/bootstrap/bootstrap.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/bootstrap-submenu/js/bootstrap-submenu.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/angular/angular.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/angular-cookies/angular-cookies.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/angular-bootstrap/ui-bootstrap-tpls.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/angular-ui-grid/ui-grid.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/d3/d3.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/nvd3/nv.d3.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/flotr2/flotr2.min.js"></script>
    <script src="../cubes/cubesviewer-2.0.2/html/lib/masonry/masonry.pkgd.min.js"></script>  <!-- needed for CubesViewer Studio only, not embedded views -->
    <script src="../cubes/cubesviewer-2.0.2/dist/cubesviewer.js"></script>
HRERDOC;
}



function PrintStudioSbodyScript(){
echo <<<HRERDOC
<script type="text/javascript">

    // Initialize CubesViewer when document is ready
    $(document).ready(function() {

    	var cubesUrl = prompt ("Enter your Cubes Server URL or try http://cubesdemo.cubesviewer.com", "http://localhost:5000");
        //var cubesUrl = "http://localhost:5000";

        cubesviewerStudio.init({
        	cubesUrl: cubesUrl,
            container: $('#cubesviewer').get(0),
            debug: true
        });

    });

</script>
HRERDOC;
}



function PrintStudioSBody(){
echo <<<HEREDOC
<div class="header">
        <div style="float: left;">
            <img class="cv-logo" title="CubesViewer" src="../cubes/cubesviewer-2.0.2/html/img/cubesviewer-logo.png" />
        </div>
        <h1>CubesViewer Studio</h1>
        <small>Local HTML version (<a href="https://github.com/jjmontesl/cubesviewer-server" target="_blank">server-side features</a> are not available)</small>

    </div>

    <div style="clear: both;"></div>
    <!-- Cubes Viewer container -->
    <div id="cubesviewer"></div>
	
    <div class="footer" style="clear: both; padding-top: 20px;">
    	<div style="height: 1px; border-top: 1px solid #DDDDDD; padding-top: 4px;"></div>
    	<div style="float: right; white-space: nowrap;">
    		<p style="vertical-align: middle; margin: 2px;">
    		<a href="http://databrewery.org/" target="_blank"><img title="Powered by Databrewery Cubes" style="width: 70px; height: 25px;" src="../cubes/cubesviewer-2.0.2/html/img/cubes-logo.png" /></a>
            <a href="https://github.com/jjmontesl/cubesviewer" target="_blank"><img title="Powered by CubesViewer" style="width: 50px; height: 25px;" src="../cubes/cubesviewer-2.0.2/html/img/cubesviewer-logo.png" /></a>
    		</p>
    	</div>
    	<div>
    		<p><a href="https://github.com/jjmontesl/cubesviewer" target="_blank">CubesViewer</a> <span class="cv-version"></span> - Cubes OLAP explorer</p>
    	</div>
    </div>
HEREDOC;
}


?>