﻿<?php
if(isset($passSQL))
{
	$query=$passSQL." limit $begin,$limit;";
}else{
	$query = "select * from `joinjoin_true` where joinjoin_true.species_chinesename = ".'"'.$animalChineseName.'"'." limit $begin,$limit;";
}
//连接数据库
$conn = @mysqli_connect("127.0.0.1","guest","guest",$db);
if(mysqli_connect_errno($conn))
{
	die("无法连接数据库，请联系服务器管理员");
}else{
	mysqli_set_charset($conn,"utf8");
	$query = mysqli_real_escape_string($conn,$query);
	$query = str_replace("\\","",$query);
	//echo $query."\n";
}

$result = mysqli_query($conn,$query);


function printSQLresultAsTable(){
	global $conn;
	global $result;
//输出表头
echo <<<tableHead
<table class="table">
<caption>查询结果<caption>
<thead>
tableHead;
echo '<tr>';
$fetch_fields = mysqli_fetch_fields($result);
foreach($fetch_fields as $column)
{
	echo "<th class=\"warning\">$column->name</th>";
}
echo "<th class=\"warning\">Select</th>";//添加选择的表头
echo "</tr>";
echo '</thead>';
//逐行输出数据表
echo "<tbody>";
	while($row=mysqli_fetch_array($result,MYSQLI_NUM))
	{
		if($row[5]=='TRUE')
		{
				echo '<tr class="success">';
		}else{
			    echo '<tr class="danger">';
		}
		foreach($row as $value)
		{
			echo "<td>$value</td>";
		}
		//添加选择按钮,带有pubmedid和geneid
echo '
<td>
<div class="switch" style="display:inline"> <input type="checkbox" style="float:right" name="checkbox_row" checked '.'pubmedid="'.$row[4].'" geneid="'.$row[7].'"/></div>
</td>
';
		//添加选择按钮结束
		echo "</tr>";
	}
//表格尾添加post2cytoscape.js的按钮
echo <<<POST2CYTOSCAPE
<tr class="success">
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
<td>
<button type="button" class="btn btn-primary" id="myButton4" 
   	data-complete-text="Loading finished" onclick="gocytoscape()">
Go_CYtoscape.js
</button>
</td>
</tr>
POST2CYTOSCAPE;
echo "</tbody>";
}
mysqli_close($conn);

?>