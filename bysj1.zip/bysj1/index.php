<!DOCTYPE html>
<html lang="en">
<!--html lang="en" manifest="statci_index.appcache"-->
<head>
  <title>Domestic Fertility Database</title>
  <meta charset="utf-8">
  <meta name="author" content="szj">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name= "keyword" content="demostic fertility">
   <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/default.index.css">
    <script type="text/javascript" src="//ra.revolvermaps.com/0/0/5.js?i=0o5xmrmtegg&amp;m=1&amp;c=ff0000&amp;cr1=ffffff&amp;b=100&amp;v=100&amp;lx=600&amp;ly=360" async="async"></script>
 </head>
 
<body>

<div class=" container" id="header" >
<div class="jumbotron">
    <h1><strong>Demoestic Fertility Database<strong></h1><!--加入说明文字><-->
</div>
<!--加入导航栏-->
<ul class="nav nav-tabs nav-justified">
	<li class="active"><a href="#">Home</a></li>
	<li><a href="search.php">Search</a></li>
	<li><a href="download.php">Download</a></li>
	<li><a href="/cubes/cubesviewer-2.0.2/html/studio1.html">Analyse</a></li>
	<li><a href="contact.php">Contact</a></li>
</ul>
<!--导航栏加入结束-->
</div>

<div class="container" id="body" style="padding:20px">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title"  style="height:50px;" font-size="xx-larger">
			Introduction & Database Information
			</h3>
		</div>
		
		
		<div class="panel-body">
			<div class="panel panel-default" style="display:inline;float:left;width:49%">
				<div class="panel-heading" style="font-size:x-large;font-style:oblique">
				Introduction To DTD
				</div>
				<div class="panel-body" style="font-size:large">
				<p class="text-primary">DTD ,  a Information Integreted Database related to domestic fertility deriverd mianly from the Pubmed Database Provides you with the services of Database Query ,  Simple Cytoscape Network Displaying , Data Downlading  and Simple Big Data OLAP which is the feature BUT for testing.</p>
				<p class="text-primary">We selected 6 species of demostic aninmal  consisted of Pig , Sheep , Goat , Bovine , Horse , Donkey  AND 3 kind of domestic bird of Chicken , Goose , Duck in 123 kind of word  in which one may represents a subspecies in the database , 614 kind of term selected from three pespectives that animal husbandry production index , physiology , physiopathology related to animal fertility cross combinated with the animal name  which method is a easy way to organize the database having no negative effects but positive ones on the purpose of finding new traits related genes because of the uncertainty of data returned by pubmed searching engine when searching so that the enlarged the data amouunt.</p>
				<p class="text-primary">       </p>
				
				
				</div>
			</div>
			
			<div class="panel panel-default" style="display:inline;float:right;width:49%">
				<div class="panel-heading" style="font-size:x-large;font-style:oblique">
				Database Information
				</div>
				<div class="panel-body">
				into
				</div>
			</div>
			
			
		</div>	
		<div class="separator line"><div></div></div>
		面板内容
	</div>
</div>
		</div>
	</div>
</div>
<div class = "container" id="footer">
<div class="panel panel-default" style="display:inline:block;float:left;width:100%;background-color:#282e38;height:auto">
	
	<div style="text-align:center;float:left;width:80%">
	<p class="text-primary" style="">&nbsp;&nbsp;&nbsp;</p>
	<p class="text-primary" style="">© Copyright © 2015. College of Life Sciences, E207. Northwest A&F University, China</p>
	<p class="text-primary" style="">Firefox and Chrome with 1024*768 (or higher) are preferred</p>
	<p class="text-primary" style=""></p>
	</div>
	<div style="text-align:center;float:right; margin:0; padding:0; width:100px;"><embed src="//ra.revolvermaps.com/f/f.swf" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="window" allowScriptAccess="always" allowNetworking="all" width="100" height="50" flashvars="m=0&amp;i=0w0fxamap55&amp;r=0&amp;c=ff0000"></embed><br /><img src="//ra.revolvermaps.com/js/c/0w0fxamap55.gif" width="1" height="1" alt="" /><a href="http://www.revolvermaps.com/?target=enlarge&amp;i=0w0fxamap55">Large Visitor Map</a></div>
</div>
</div>




</body>
</html>