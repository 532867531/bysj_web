﻿<?php
echo <<<HEREDOC
</div>
<div class = "container" id="footer">
填入脚信息
<div>
</body>
</html>
HEREDOC;
?>